package librerias.estructurasDeDatos.lineales;


/**
 * Mantiene oredenados ascendentemente los elementos de una Lista.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class LEGListaConPIOrdenada<E extends Comparable<E>> extends LEGListaConPI<E>{
    // instance variables - replace the example below with your own
    
    
    /**
     * Constructor for objects of class LEGListaConPIOrdenada
     */
    public LEGListaConPIOrdenada() {
        // initialise instance variables
        super();
    }
    
    public void insertar (E e){
        
        inicio();
        while(!esFin() && recuperar().compareTo(e)<0){
            siguiente();
        }
        super.insertar(e);
        }
        
    public E recuperararMin(){
       inicio(); 
        return recuperar();
    }
        
    }

